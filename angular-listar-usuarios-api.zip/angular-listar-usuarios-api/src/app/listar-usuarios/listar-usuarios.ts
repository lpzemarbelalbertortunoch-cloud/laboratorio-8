import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsuarioService } from './service/usuario';
import { Usuario } from './interface/usuario-model';

@Component({
  selector: 'app-listar-usuarios',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './listar-usuarios.html',
  styleUrl: './listar-usuarios.scss'
})
export class ListarUsuarios implements OnInit {

  usuarios: Usuario[] = [];
  cargando = false;
  mensajeError = '';

  constructor(private usuarioService: UsuarioService) {
  }

  ngOnInit(): void {
    this.obtenerUsuarios();
  }

  obtenerUsuarios(): void {
    this.cargando = true;
    this.mensajeError = '';

    this.usuarioService.listarUsuarios().subscribe({
      next: (respuesta: Usuario[]) => {
        this.usuarios = respuesta;
        this.cargando = false;
        console.log('Usuarios recibidos:', respuesta);
      },
      error: (error) => {
        console.error('Error al listar usuarios:', error);
        this.mensajeError = 'No se pudieron cargar los usuarios.';
        this.cargando = false;
      }
    });
  }
}

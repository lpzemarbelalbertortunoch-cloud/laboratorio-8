PROYECTO: Angular - Listar Usuarios con API

Este proyecto consume la API:
https://jsonplaceholder.typicode.com/users

ESTRUCTURA PRINCIPAL
src/app/listar-usuarios/
  interface/usuario-model.ts
  service/usuario.ts
  listar-usuarios.ts
  listar-usuarios.html
  listar-usuarios.scss

ABRIR EN INTELLIJ IDEA
1. Descomprime el ZIP.
2. En IntelliJ IDEA: File > Open.
3. Selecciona la carpeta angular-listar-usuarios-api.
4. Abre la terminal de IntelliJ.
5. Ejecuta:

   npm install

6. Cuando termine, ejecuta:

   npm start

   o también:

   ng serve

7. Abre en el navegador:
   http://localhost:4200

COMO FUNCIONA
- usuario-model.ts define la interfaz Usuario.
- usuario.ts es el servicio y usa HttpClient.
- listarUsuarios() realiza un GET a la API.
- listar-usuarios.ts se suscribe al Observable y guarda la respuesta.
- listar-usuarios.html recorre los usuarios con *ngFor y los muestra en una tabla.
- app.config.ts contiene provideHttpClient().

METODO DEL SERVICIO
listarUsuarios(): Observable<Usuario[]> {
  return this.http.get<Usuario[]>(this.url);
}

API UTILIZADA
GET https://jsonplaceholder.typicode.com/users

import { Component } from '@angular/core';
import { ListarUsuarios } from './listar-usuarios/listar-usuarios';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [ListarUsuarios],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
}

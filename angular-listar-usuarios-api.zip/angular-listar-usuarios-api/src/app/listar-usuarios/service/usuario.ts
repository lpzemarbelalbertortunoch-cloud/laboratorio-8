import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Usuario } from '../interface/usuario-model';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  private readonly url: string = 'https://jsonplaceholder.typicode.com/users';

  constructor(private http: HttpClient) {
  }

  listarUsuarios(): Observable<Usuario[]> {
    return this.http.get<Usuario[]>(this.url);
  }
}
